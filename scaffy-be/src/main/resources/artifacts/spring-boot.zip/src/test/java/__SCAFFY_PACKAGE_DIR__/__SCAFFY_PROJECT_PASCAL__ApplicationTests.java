package __SCAFFY_PACKAGE__;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class __SCAFFY_PROJECT_PASCAL__ApplicationTests {

	@Test
	void contextLoads() {
	}

}
