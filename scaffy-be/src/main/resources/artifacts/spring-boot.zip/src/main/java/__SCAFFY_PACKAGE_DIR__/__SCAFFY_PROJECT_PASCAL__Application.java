package __SCAFFY_PACKAGE__;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class __SCAFFY_PROJECT_PASCAL__Application {

	public static void main(String[] args) {
		SpringApplication.run(__SCAFFY_PROJECT_PASCAL__Application.class, args);
	}

}
